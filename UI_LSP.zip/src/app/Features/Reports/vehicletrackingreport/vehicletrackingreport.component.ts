import { Component } from '@angular/core';

@Component({
  selector: 'app-vehicletrackingreport',
  standalone: true,
  imports: [],
  templateUrl: './vehicletrackingreport.component.html',
  styleUrl: './vehicletrackingreport.component.css'
})
export class VehicletrackingreportComponent {

}
